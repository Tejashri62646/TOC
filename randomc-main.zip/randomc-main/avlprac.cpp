#include <iostream>
#include <stack>
using namespace std;
struct AVLNode {
    int data;
    AVLNode* left;
    AVLNode* right;
    int height;   
    AVLNode(int val) : data(val), left(nullptr), right(nullptr), height(1) {}
};

class AVLTree {
private:
    AVLNode* root;    
    int height(AVLNode* n) { 
        return n ? n->height : 0; }
    void updateHeight(AVLNode* n) {
        n->height = 1 + max(height(n->left), height(n->right));
    }    
    int balanceFactor(AVLNode* n) {
        return n ? height(n->left) - height(n->right) : 0;
    }
    AVLNode* rotateRight(AVLNode* y) {
        AVLNode* x  = y->left;
        AVLNode* T2 = x->right;
        x->right = y;
        y->left  = T2;
        updateHeight(y);
        updateHeight(x);
        return x;
    }
 
    AVLNode* rotateLeft(AVLNode* x) {
        AVLNode* y  = x->right;
        AVLNode* T2 = y->left;
        y->left  = x;
        x->right = T2;
        updateHeight(x);
        updateHeight(y);
        return y;
    }
    
    AVLNode* balance(AVLNode* node) {
        updateHeight(node);
        int bf = balanceFactor(node);
    
        if (bf > 1 && balanceFactor(node->left) >= 0)
            return rotateRight(node);

        if (bf > 1 && balanceFactor(node->left) < 0) {
            node->left = rotateLeft(node->left);
            return rotateRight(node);
        }

        if (bf < -1 && balanceFactor(node->right) <= 0)
            return rotateLeft(node);

        
        if (bf < -1 && balanceFactor(node->right) > 0) {
            node->right = rotateRight(node->right);
            return rotateLeft(node);
        }

        return node;   
    }

    
    AVLNode* insertHelper(AVLNode* node, int val) {
        if (!node) return new AVLNode(val);
        if (val < node->data)      node->left  = insertHelper(node->left,  val);
        else if (val > node->data) node->right = insertHelper(node->right, val);
        else return node;  
        return balance(node);
    }

    
    void inRec(AVLNode* n)   { if (!n) return; inRec(n->left); cout << n->data << " "; inRec(n->right); }
    void preRec(AVLNode* n)  { if (!n) return; cout << n->data << " "; preRec(n->left); preRec(n->right); }
    void postRec(AVLNode* n) { if (!n) return; postRec(n->left); postRec(n->right); cout << n->data << " "; }

public:
    AVLTree() : root(nullptr) {}

    void insert(int val) { root = insertHelper(root, val); }

    
    void inorderR()   { cout << "Inorder(R): ";   inRec(root);   cout << "\n"; }
    void preorderR()  { cout << "Preorder(R): ";  preRec(root);  cout << "\n"; }
    void postorderR() { cout << "Postorder(R): "; postRec(root); cout << "\n"; }

    
    void inorderNR() {
        cout << "Inorder(NR): ";
        stack<AVLNode*> st; AVLNode* curr = root;
        while (curr || !st.empty()) {
            while (curr) { st.push(curr); curr = curr->left; }
            curr = st.top(); st.pop();
            cout << curr->data << " ";
            curr = curr->right;
        }
        cout << "\n";
    }

    void preorderNR() {
        cout << "Preorder(NR): ";
        if (!root) { cout << "\n"; return; }
        stack<AVLNode*> st; st.push(root);
        while (!st.empty()) {
            AVLNode* n = st.top(); st.pop();
            cout << n->data << " ";
            if (n->right) st.push(n->right);
            if (n->left)  st.push(n->left);
        }
        cout << "\n";
    }

    void postorderNR() {
        cout << "Postorder(NR): ";
        if (!root) { cout << "\n"; return; }
        stack<AVLNode*> s1, s2; s1.push(root);
        while (!s1.empty()) {
            AVLNode* n = s1.top(); s1.pop(); s2.push(n);
            if (n->left)  s1.push(n->left);
            if (n->right) s1.push(n->right);
        }
        while (!s2.empty()) { cout << s2.top()->data << " "; s2.pop(); }
        cout << "\n";
    }

    
    void printBF(AVLNode* node) {
        if (!node) return;
        printBF(node->left);
        cout << node->data << "(BF=" << balanceFactor(node) << ") ";
        printBF(node->right);
    }
    void showBalanceFactors() {
        cout << "Balance Factors: "; printBF(root); cout << "\n";
    }
};

int main() {
    AVLTree tree; int ch, val;
    cout << "===== AVL TREE =====\n";
    do {
        cout << "\n1.Insert 2.In(R) 3.Pre(R) 4.Post(R)"
             << "\n5.In(NR) 6.Pre(NR) 7.Post(NR) 8.Balance Factors 0.Exit\nChoice: ";
        cin >> ch;
        if (ch == 1) { cout << "Value: "; cin >> val; }
        switch(ch) {
            case 1: tree.insert(val);           break;
            case 2: tree.inorderR();            break;
            case 3: tree.preorderR();           break;
            case 4: tree.postorderR();          break;
            case 5: tree.inorderNR();           break;
            case 6: tree.preorderNR();          break;
            case 7: tree.postorderNR();         break;
            case 8: tree.showBalanceFactors();  break;
            case 0: cout << "Bye!\n"; break;
        }
    } while(ch != 0);
    return 0;
}