/*
 * PRACTICAL 05 — HEAP SORT
 * Sorts in both ascending (max-heap) and descending (min-heap) order
 * Time Complexity: O(n log n) — all cases
 * Space Complexity: O(1) — in-place sorting
 */

#include <iostream>
using namespace std;

class HeapSort {
private:
    int arr[100];
    int n;

    // ── MAX-HEAPIFY ──────────────────────────────
    // Ensures subtree rooted at index i satisfies max-heap property
    // parent >= both children
    void maxHeapify(int arr[], int n, int i) {
        int largest = i;        // assume root is largest
        int left    = 2*i + 1;  // left child index
        int right   = 2*i + 2;  // right child index

        // Is left child larger than current largest?
        if (left < n && arr[left] > arr[largest])
            largest = left;

        // Is right child larger than current largest?
        if (right < n && arr[right] > arr[largest])
            largest = right;

        // If largest is not root — swap and continue heapifying down
        if (largest != i) {
            swap(arr[i], arr[largest]);
            maxHeapify(arr, n, largest);  // fix the affected subtree
        }
    }

    // ── MIN-HEAPIFY ──────────────────────────────
    // Same logic but parent <= children (for descending sort)
    void minHeapify(int arr[], int n, int i) {
        int smallest = i;
        int left     = 2*i + 1;
        int right    = 2*i + 2;

        if (left  < n && arr[left]  < arr[smallest]) smallest = left;
        if (right < n && arr[right] < arr[smallest]) smallest = right;

        if (smallest != i) {
            swap(arr[i], arr[smallest]);
            minHeapify(arr, n, smallest);
        }
    }

public:
    void input() {
        cout << "Enter number of elements: ";
        cin >> n;
        cout << "Enter elements: ";
        for (int i = 0; i < n; i++)
            cin >> arr[i];
    }

    // ── ASCENDING SORT (using max-heap) ──────────
    void sortAscending() {
        // Phase 1: Build max-heap
        // Start from last non-leaf node = n/2-1, go to root
        for (int i = n/2 - 1; i >= 0; i--)
            maxHeapify(arr, n, i);

        // Phase 2: Extract elements one by one
        for (int i = n - 1; i > 0; i--) {
            // Move current max (arr[0]) to end
            swap(arr[0], arr[i]);
            // Heapify the reduced heap (ignore sorted tail)
            maxHeapify(arr, i, 0);
        }

        cout << "\nAscending order: ";
        for (int i = 0; i < n; i++)
            cout << arr[i] << " ";
        cout << "\n";
    }

    // ── DESCENDING SORT (using min-heap) ─────────
    void sortDescending() {
        // Re-read the original array (reset)
        cout << "Enter elements again for descending: ";
        for (int i = 0; i < n; i++)
            cin >> arr[i];

        // Phase 1: Build min-heap
        for (int i = n/2 - 1; i >= 0; i--)
            minHeapify(arr, n, i);

        // Phase 2: Extract elements one by one
        for (int i = n - 1; i > 0; i--) {
            swap(arr[0], arr[i]);
            minHeapify(arr, i, 0);
        }

        cout << "\nDescending order: ";
        for (int i = 0; i < n; i++)
            cout << arr[i] << " ";
        cout << "\n";
    }
};

int main() {
    HeapSort h;
    int choice;

    cout << "===== HEAP SORT =====\n";
    do {
        cout << "\n1. Sort Ascending\n";
        cout << "2. Sort Descending\n";
        cout << "0. Exit\n";
        cout << "Choice: ";
        cin >> choice;

        switch(choice) {
            case 1:
                h.input();
                h.sortAscending();
                break;
            case 2:
                h.input();
                h.sortDescending();
                break;
            case 0:
                cout << "Bye!\n";
                break;
            default:
                cout << "Invalid!\n";
        }
    } while(choice != 0);

    return 0;
}