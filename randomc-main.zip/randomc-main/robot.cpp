#include<iostream>
#include<algorithm>
using namespace std;

class Edge{
public:

    int u,v,w;
};

bool cmp(Edge a,Edge b){

    return a.w<b.w;
}

int parent[100];

int find(int x){

    if(parent[x]==x)
        return x;

    return parent[x]=find(parent[x]);
}

void unite(int a,int b){

    parent[find(a)]=find(b);
}

int main(){

    int v,e;

    cin>>v>>e;

    Edge ed[e];

    for(int i=0;i<e;i++)
        cin>>ed[i].u>>ed[i].v>>ed[i].w;

    sort(ed,ed+e,cmp);

    for(int i=0;i<v;i++)
        parent[i]=i;

    int cost=0;

    cout<<"Minimum Path:\n";

    for(int i=0;i<e;i++){

        int a=find(ed[i].u);

        int b=find(ed[i].v);

        if(a!=b){

            cout<<ed[i].u<<" - "
                <<ed[i].v<<" = "
                <<ed[i].w<<endl;

            cost+=ed[i].w;

            unite(a,b);
        }
    }

    cout<<"Total Cost: "<<cost;
}