#include<iostream>
using namespace std;

class Node{
public:

    int data;
    Node *left,*right;

    Node(int x){

        data=x;

        left=right=NULL;
    }
};

class BST{
public:

    Node *root=NULL;

    Node* insert(Node *r,int x){

        if(r==NULL)
            return new Node(x);

        if(x<r->data)
            r->left=insert(r->left,x);

        else
            r->right=insert(r->right,x);

        return r;
    }

    void inorder(Node *r){

        if(r){

            inorder(r->left);

            cout<<r->data<<" ";

            inorder(r->right);
        }
    }
};

int main(){

    BST b;

    int n,x;

    cin>>n;

    for(int i=0;i<n;i++){

        cin>>x;

        b.root=b.insert(b.root,x);
    }

    cout<<"Sorted Data:\n";

    b.inorder(b.root);
}