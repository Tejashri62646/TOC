

#include <iostream>
#include <stack>
using namespace std;


struct TNode {
    int data;
    TNode* left;
    TNode* right;
    bool isLeftThread;   
    bool isRightThread;  

    TNode(int val) {
        data = val;
        left = right = nullptr;
        isLeftThread = isRightThread = true; 
    }
};


class ThreadedBST {
private:
    TNode* root;

public:
    ThreadedBST() : root(nullptr) {}

    
    void insert(int val) {
        TNode* newNode = new TNode(val);

        if (!root) {
            root = newNode;
            newNode->left  = nullptr;
            newNode->right = nullptr;
            return;
        }

        TNode* curr = root;
        while (true) {
            if (val < curr->data) {
                if (curr->isLeftThread) {    
                    newNode->left  = curr->left;   
                    newNode->right = curr;          
                    curr->left = newNode;
                    curr->isLeftThread = false;     
                    break;
                } else curr = curr->left;
            } else {
                if (curr->isRightThread) {   
                    newNode->right = curr->right;  
                    newNode->left  = curr;          
                    curr->right = newNode;
                    curr->isRightThread = false;    
                    break;
                } else curr = curr->right;
            }
        }
    }

    
    TNode* leftMost(TNode* node) {
        while (node && !node->isLeftThread)
            node = node->left;
        return node;
    }

    
    void inorderNR() {
        cout << "Inorder(NR): ";
        TNode* curr = leftMost(root);
        while (curr) {
            cout << curr->data << " ";
            if (curr->isRightThread) curr = curr->right;  
            else curr = leftMost(curr->right);             
        }
        cout << "\n";
    }

    
    void preorderNR() {
        cout << "Preorder(NR): ";
        TNode* curr = root;
        while (curr) {
            cout << curr->data << " ";
            if (!curr->isLeftThread)       curr = curr->left;   
            else if (!curr->isRightThread) curr = curr->right;  
            else {
                
                while (curr && curr->isRightThread) curr = curr->right;
                if (curr) curr = curr->right;
            }
        }
        cout << "\n";
    }

    
    
    void collectInorder(TNode* node, int arr[], int& idx) {
        
        TNode* curr = leftMost(node);
        while (curr) {
            arr[idx++] = curr->data;
            if (curr->isRightThread) curr = curr->right;
            else curr = leftMost(curr->right);
        }
    }

    
    
    void inorderR()   {
        cout << "Inorder(R): "; inorderNR(); 
    }
    void preorderR()  {
        cout << "Preorder(R): "; preorderNR();
    }

    
    void postorderNR() {
        cout << "Postorder(NR): ";
        if (!root) { cout << "\n"; return; }

        
        
        stack<TNode*> s1, s2;
        s1.push(root);
        while (!s1.empty()) {
            TNode* n = s1.top(); s1.pop();
            s2.push(n);
            if (!n->isLeftThread  && n->left)  s1.push(n->left);
            if (!n->isRightThread && n->right) s1.push(n->right);
        }
        while (!s2.empty()) { cout << s2.top()->data << " "; s2.pop(); }
        cout << "\n";
    }
    void postorderR() {
        cout << "Postorder(R): "; postorderNR();
    }
};

int main() {
    ThreadedBST tree; int ch, val;
    cout << "===== THREADED BINARY TREE =====\n";
    do {
        cout << "\n1.Insert 2.Inorder(R) 3.Preorder(R) 4.Postorder(R)"
             << "\n5.Inorder(NR) 6.Preorder(NR) 7.Postorder(NR) 0.Exit\nChoice: ";
        cin >> ch;
        if (ch == 1) { cout << "Value: "; cin >> val; }
        switch(ch) {
            case 1: tree.insert(val);    break;
            case 2: tree.inorderR();     break;
            case 3: tree.preorderR();    break;
            case 4: tree.postorderR();   break;
            case 5: tree.inorderNR();    break;
            case 6: tree.preorderNR();   break;
            case 7: tree.postorderNR();  break;
            case 0: cout << "Bye!\n"; break;
        }
    } while(ch != 0);
    return 0;
}