#include <iostream>
#include <queue>
#include <stack>
using namespace std;


struct Node {
    int data;
    Node* left;
    Node* right;
    Node(int val) : data(val), left(nullptr), right(nullptr) {}
};


class BST {
private:
    Node* root;

    Node* insertHelper(Node* node, int val) {
        if (!node) return new Node(val);
        if (val < node->data)      node->left  = insertHelper(node->left,  val);
        else if (val > node->data) node->right = insertHelper(node->right, val);
        return node;
    }

    Node* minNode(Node* node) {
        while (node->left) node = node->left;
        return node;
    }

    Node* deleteHelper(Node* node, int val) {
        if (!node) { cout << val << " not found.\n"; return nullptr; }
        if (val < node->data)      node->left  = deleteHelper(node->left,  val);
        else if (val > node->data) node->right = deleteHelper(node->right, val);
        else {
            
            if (!node->left && !node->right) { delete node; return nullptr; }
            
            if (!node->left)  { Node* t = node->right; delete node; return t; }
            if (!node->right) { Node* t = node->left;  delete node; return t; }
            
            Node* succ = minNode(node->right);
            node->data = succ->data;
            node->right = deleteHelper(node->right, succ->data);
        }
        return node;
    }

    void inRec(Node* n)   { if (!n) return; inRec(n->left); cout << n->data << " "; inRec(n->right); }
    void preRec(Node* n)  { if (!n) return; cout << n->data << " "; preRec(n->left);  preRec(n->right); }
    void postRec(Node* n) { if (!n) return; postRec(n->left); postRec(n->right); cout << n->data << " "; }

public:
    BST() : root(nullptr) {}

    void insert(int val)     { root = insertHelper(root, val); }
    void deleteNode(int val) { root = deleteHelper(root, val); }

    
    void inorderR()   { cout << "Inorder(R): ";   inRec(root);   cout << "\n"; }
    void preorderR()  { cout << "Preorder(R): ";  preRec(root);  cout << "\n"; }
    void postorderR() { cout << "Postorder(R): "; postRec(root); cout << "\n"; }

    
    void inorderNR() {
        cout << "Inorder(NR): ";
        stack<Node*> st; Node* curr = root;
        while (curr || !st.empty()) {
            while (curr) { st.push(curr); curr = curr->left; }
            curr = st.top(); st.pop();
            cout << curr->data << " ";
            curr = curr->right;
        }
        cout << "\n";
    }

    void preorderNR() {
        cout << "Preorder(NR): ";
        if (!root) { cout << "\n"; return; }
        stack<Node*> st; st.push(root);
        while (!st.empty()) {
            Node* n = st.top(); st.pop();
            cout << n->data << " ";
            if (n->right) st.push(n->right);
            if (n->left)  st.push(n->left);
        }
        cout << "\n";
    }

    void postorderNR() {
        cout << "Postorder(NR): ";
        if (!root) { cout << "\n"; return; }
        stack<Node*> s1, s2; s1.push(root);
        while (!s1.empty()) {
            Node* n = s1.top(); s1.pop(); s2.push(n);
            if (n->left)  s1.push(n->left);
            if (n->right) s1.push(n->right);
        }
        while (!s2.empty()) { cout << s2.top()->data << " "; s2.pop(); }
        cout << "\n";
    }

    
    void levelWise() {
        if (!root) { cout << "Empty tree.\n"; return; }
        queue<Node*> q; q.push(root); int lvl = 1;
        while (!q.empty()) {
            int sz = q.size();
            cout << "Level " << lvl++ << ": ";
            for (int i = 0; i < sz; i++) {
                Node* n = q.front(); q.pop();
                cout << n->data << " ";
                if (n->left)  q.push(n->left);
                if (n->right) q.push(n->right);
            }
            cout << "\n";
        }
    }
};

int main() {
    BST tree; int ch, val;
    cout << "===== BINARY SEARCH TREE =====\n";
    do {
        cout << "\n1.Insert 2.Delete 3.In(R) 4.Pre(R) 5.Post(R)"
             << "\n6.In(NR) 7.Pre(NR) 8.Post(NR) 9.LevelWise 0.Exit\nChoice: ";
        cin >> ch;
        if (ch==1||ch==2) { cout << "Value: "; cin >> val; }
        switch(ch) {
            case 1: tree.insert(val);     break;
            case 2: tree.deleteNode(val); break;
            case 3: tree.inorderR();      break;
            case 4: tree.preorderR();     break;
            case 5: tree.postorderR();    break;
            case 6: tree.inorderNR();     break;
            case 7: tree.preorderNR();    break;
            case 8: tree.postorderNR();   break;
            case 9: tree.levelWise();     break;
            case 0: cout << "Bye!\n"; break;
            default: cout << "Invalid!\n";
        }
    } while(ch != 0);
    return 0;
}