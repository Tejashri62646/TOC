/*
 * PRACTICAL 04 — MINIMUM SPANNING TREE
 * Prim's Algorithm
 * Uses adjacency matrix + greedy selection
 * Time: O(V²)
 */

#include <iostream>
#include <climits>    // for INT_MAX
using namespace std;

#define MAX 10
#define INF INT_MAX

class PrimMST {
private:
    int graph[MAX][MAX];  // adjacency matrix
    int V;                // number of vertices

    // Find vertex with minimum key value not yet in MST
    int minKey(int key[], bool inMST[]) {
        int min = INF, minIndex = -1;
        for (int v = 0; v < V; v++) {
            if (!inMST[v] && key[v] < min) {
                min = key[v];
                minIndex = v;
            }
        }
        return minIndex;
    }

public:
    void input() {
        cout << "Enter number of vertices: ";
        cin >> V;
        cout << "Enter adjacency matrix (0 if no edge):\n";
        for (int i = 0; i < V; i++)
            for (int j = 0; j < V; j++) {
                cin >> graph[i][j];
                if (graph[i][j] == 0 && i != j)
                    graph[i][j] = INF;  // no edge = infinity
            }
    }

    void primMST() {
        int parent[MAX];   // stores MST structure
        int key[MAX];      // min weight edge to reach each vertex
        bool inMST[MAX];   // true if vertex is in MST

        // Initialize all keys as infinite, none in MST
        for (int i = 0; i < V; i++) {
            key[i]   = INF;
            inMST[i] = false;
            parent[i] = -1;
        }

        key[0] = 0;  // start from vertex 0

        for (int count = 0; count < V - 1; count++) {
            // Pick vertex with minimum key not yet in MST
            int u = minKey(key, inMST);
            inMST[u] = true;  // add u to MST

            // Update key values of adjacent vertices
            for (int v = 0; v < V; v++) {
                if (graph[u][v] != INF   // edge exists
                    && !inMST[v]         // v not yet in MST
                    && graph[u][v] < key[v]) {  // cheaper path found
                    parent[v] = u;
                    key[v]    = graph[u][v];
                }
            }
        }

        // Print MST
        int totalCost = 0;
        cout << "\n--- Prim's MST ---\n";
        cout << "Edge\t\tWeight\n";
        for (int i = 1; i < V; i++) {
            cout << parent[i] << " - " << i
                 << "\t\t" << graph[i][parent[i]] << "\n";
            totalCost += graph[i][parent[i]];
        }
        cout << "Total MST cost: " << totalCost << "\n";
    }
};

int main() {
    PrimMST p;
    p.input();
    p.primMST();
    return 0;
}