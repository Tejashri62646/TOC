/*
 * PRACTICAL 06 — PROBABILISTIC DATA STRUCTURES
 * PART A: Bloom Filter
 *
 * Answers: "Is element x in the set?"
 * DEFINITELY NOT  → if any hash bit is 0
 * PROBABLY YES    → if all hash bits are 1 (may be false positive)
 *
 * Uses: bit array of size m + k hash functions
 */

#include <iostream>
#include <string>
using namespace std;

#define BLOOM_SIZE  20   // size of bit array (m)
#define NUM_HASHES   3   // number of hash functions (k)

class BloomFilter {
private:
    int bitArray[BLOOM_SIZE];  // 0 or 1 — the "bit" array

    // ── k simple hash functions ───────────────
    // Each uses a different multiplier to spread bits differently
    // For integers. For strings, we hash character by character.
    int hash1(int x) { return (x * 7)  % BLOOM_SIZE; }
    int hash2(int x) { return (x * 11) % BLOOM_SIZE; }
    int hash3(int x) { return (x * 17) % BLOOM_SIZE; }

    // String version of hashes
    int strHash1(string s) {
        int h = 0;
        for (char c : s) h = (h * 7  + c) % BLOOM_SIZE;
        return h;
    }
    int strHash2(string s) {
        int h = 0;
        for (char c : s) h = (h * 11 + c) % BLOOM_SIZE;
        return h;
    }
    int strHash3(string s) {
        int h = 0;
        for (char c : s) h = (h * 17 + c) % BLOOM_SIZE;
        return h;
    }

public:
    BloomFilter() {
        // Initialise all bits to 0
        for (int i = 0; i < BLOOM_SIZE; i++)
            bitArray[i] = 0;
    }

    // ── INSERT (integer) ─────────────────────
    void insert(int x) {
        bitArray[hash1(x)] = 1;
        bitArray[hash2(x)] = 1;
        bitArray[hash3(x)] = 1;
        cout << "Inserted " << x << " at bits: "
             << hash1(x) << ", " << hash2(x) << ", " << hash3(x) << "\n";
    }

    // ── QUERY (integer) ──────────────────────
    void query(int x) {
        if (bitArray[hash1(x)] == 1 &&
            bitArray[hash2(x)] == 1 &&
            bitArray[hash3(x)] == 1)
            cout << x << " is PROBABLY IN the set.\n";
        else
            cout << x << " is DEFINITELY NOT in the set.\n";
    }

    // ── INSERT (string) ──────────────────────
    void insertStr(string s) {
        bitArray[strHash1(s)] = 1;
        bitArray[strHash2(s)] = 1;
        bitArray[strHash3(s)] = 1;
        cout << "Inserted \"" << s << "\" at bits: "
             << strHash1(s) << ", " << strHash2(s) << ", " << strHash3(s) << "\n";
    }

    // ── QUERY (string) ───────────────────────
    void queryStr(string s) {
        if (bitArray[strHash1(s)] == 1 &&
            bitArray[strHash2(s)] == 1 &&
            bitArray[strHash3(s)] == 1)
            cout << "\"" << s << "\" is PROBABLY IN the set.\n";
        else
            cout << "\"" << s << "\" is DEFINITELY NOT in the set.\n";
    }

    // ── DISPLAY bit array ────────────────────
    void display() {
        cout << "Bit array: ";
        for (int i = 0; i < BLOOM_SIZE; i++)
            cout << bitArray[i];
        cout << "\n";
    }
};

// ── MAIN ─────────────────────────────────────
int main() {
    BloomFilter bf;
    int choice, val;
    string s;

    cout << "===== BLOOM FILTER =====\n";
    do {
        cout << "\n1. Insert integer\n";
        cout << "2. Query integer\n";
        cout << "3. Insert string\n";
        cout << "4. Query string\n";
        cout << "5. Display bit array\n";
        cout << "0. Exit\n";
        cout << "Choice: ";
        cin >> choice;

        switch(choice) {
            case 1:
                cout << "Enter integer: "; cin >> val;
                bf.insert(val);
                break;
            case 2:
                cout << "Enter integer: "; cin >> val;
                bf.query(val);
                break;
            case 3:
                cout << "Enter string: "; cin >> s;
                bf.insertStr(s);
                break;
            case 4:
                cout << "Enter string: "; cin >> s;
                bf.queryStr(s);
                break;
            case 5:
                bf.display();
                break;
            case 0:
                cout << "Bye!\n";
                break;
        }
    } while(choice != 0);

    return 0;
}