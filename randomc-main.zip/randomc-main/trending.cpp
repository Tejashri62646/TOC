#include<iostream>
using namespace std;

class CMS{
public:

    int a[2][100]={0};

    int h1(string s){

        int sum=0;

        for(char c:s)
            sum+=c;

        return sum%100;
    }

    int h2(string s){

        int sum=1;

        for(char c:s)
            sum*=c;

        return sum%100;
    }

    void add(string s){

        a[0][h1(s)]++;

        a[1][h2(s)]++;
    }

    int countFreq(string s){

        int x=a[0][h1(s)];

        int y=a[1][h2(s)];

        return min(x,y);
    }
};

int main(){

    CMS c;

    int n;

    string s[100];

    cout<<"Enter number of hashtags: ";
    cin>>n;

    for(int i=0;i<n;i++){

        cin>>s[i];

        c.add(s[i]);
    }

    cout<<"\nTrending Hashtags:\n";

    for(int i=0;i<n;i++){

        bool vis=false;

        for(int j=0;j<i;j++){

            if(s[i]==s[j]){
                vis=true;
                break;
            }
        }

        if(!vis){

            cout<<s[i]
                <<" -> "
                <<c.countFreq(s[i])
                <<endl;
        }
    }
}