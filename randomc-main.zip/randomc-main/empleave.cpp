#include<iostream>
using namespace std;

class Emp{
public:
    string name;
    int leaves;
};

void heapify(Emp a[],int n,int i){

    int smallest=i;

    int l=2*i+1;
    int r=2*i+2;

    if(l<n && a[l].leaves<a[smallest].leaves)
        smallest=l;

    if(r<n && a[r].leaves<a[smallest].leaves)
        smallest=r;

    if(smallest!=i){

        swap(a[i],a[smallest]);

        heapify(a,n,smallest);
    }
}

void heapSort(Emp a[],int n){

    for(int i=n/2-1;i>=0;i--)
        heapify(a,n,i);

    for(int i=n-1;i>0;i--){

        swap(a[0],a[i]);

        heapify(a,i,0);
    }
}

int main(){

    int n;

    cin>>n;

    Emp a[n];

    for(int i=0;i<n;i++)
        cin>>a[i].name>>a[i].leaves;

    heapSort(a,n);

    cout<<"First Three Employees:\n";

    for(int i=n-1;i>=n-3;i--)
        cout<<a[i].name<<" "<<a[i].leaves<<endl;
}