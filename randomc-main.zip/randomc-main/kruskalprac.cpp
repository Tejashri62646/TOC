/*
 * PRACTICAL 04 — MINIMUM SPANNING TREE
 * Kruskal's Algorithm
 * Uses edge list + Union-Find (DSU)
 * Time: O(E log E)
 */

#include <iostream>
#include <algorithm>  // for sort
using namespace std;

#define MAX_EDGES 50
#define MAX_V     10

// ── Edge structure ────────────────────────────
struct Edge {
    int src, dest, weight;
};

// ── Union-Find (Disjoint Set Union) ──────────
// Detects cycle: if src and dest have same parent → cycle!
class DSU {
    int parent[MAX_V], rank_[MAX_V];
public:
    void init(int n) {
        for (int i = 0; i < n; i++) {
            parent[i] = i;  // each node is its own parent
            rank_[i]  = 0;
        }
    }

    // Find root of x (with path compression)
    int find(int x) {
        if (parent[x] != x)
            parent[x] = find(parent[x]);  // compress path
        return parent[x];
    }

    // Union two sets by rank
    void unite(int x, int y) {
        int rx = find(x), ry = find(y);
        if (rank_[rx] < rank_[ry])      parent[rx] = ry;
        else if (rank_[rx] > rank_[ry]) parent[ry] = rx;
        else { parent[ry] = rx; rank_[rx]++; }
    }
};

// ── Kruskal class ─────────────────────────────
class KruskalMST {
    Edge edges[MAX_EDGES];
    int  E, V;  // number of edges, vertices
    DSU  dsu;

public:
    void input() {
        cout << "Enter number of vertices: "; cin >> V;
        cout << "Enter number of edges: ";    cin >> E;
        cout << "Enter each edge (src dest weight):\n";
        for (int i = 0; i < E; i++) {
            cin >> edges[i].src
                >> edges[i].dest
                >> edges[i].weight;
        }
    }

    // Comparator: sort edges by weight ascending
    static bool compare(Edge a, Edge b) {
        return a.weight < b.weight;
    }

    void kruskalMST() {
        // Step 1: Sort all edges by weight
        sort(edges, edges + E, compare);

        dsu.init(V);

        Edge mst[MAX_V];
        int  mstSize = 0, totalCost = 0;

        // Step 2: Pick edges one by one
        for (int i = 0; i < E && mstSize < V - 1; i++) {
            int u = edges[i].src;
            int v = edges[i].dest;

            int rootU = dsu.find(u);
            int rootV = dsu.find(v);

            // If different roots → no cycle → add to MST
            if (rootU != rootV) {
                mst[mstSize++] = edges[i];
                totalCost += edges[i].weight;
                dsu.unite(u, v);
            }
            // else: same root → adding this edge makes a cycle → skip
        }

        // Print MST
        cout << "\n--- Kruskal's MST ---\n";
        cout << "Edge\t\tWeight\n";
        for (int i = 0; i < mstSize; i++) {
            cout << mst[i].src << " - " << mst[i].dest
                 << "\t\t" << mst[i].weight << "\n";
        }
        cout << "Total MST cost: " << totalCost << "\n";
    }
};

int main() {
    int choice;
    cout << "===== MINIMUM SPANNING TREE =====\n";
    cout << "1. Prim's\n2. Kruskal's\n0. Exit\nChoice: ";
    cin >> choice;

    if (choice == 2) {
        KruskalMST k;
        k.input();
        k.kruskalMST();
    }
    return 0;
}