/*
 * PRACTICAL 06 — PROBABILISTIC DATA STRUCTURES
 * PART B: Count-Min Sketch
 *
 * Answers: "What is the approximate frequency of x?"
 * May OVERCOUNT (false positives) but never UNDERCOUNTS.
 *
 * Structure: d × w 2D integer array
 * d = number of hash functions (rows)
 * w = width / number of columns
 */

#include <iostream>
#include <string>
#include <climits>
using namespace std;

#define CMS_ROWS 3    // d: number of hash functions
#define CMS_COLS 10   // w: width of each row

class CountMinSketch {
private:
    int table[CMS_ROWS][CMS_COLS];  // the 2D count table

    // ── d different hash functions ────────────
    // Row 0: multiply by 7
    // Row 1: multiply by 13
    // Row 2: multiply by 31
    // For strings: accumulate character values
    int hashFn(int row, int x) {
        int primes[] = {7, 13, 31};
        return ((x * primes[row]) % CMS_COLS + CMS_COLS) % CMS_COLS;
    }

    int hashStr(int row, string s) {
        int primes[] = {7, 13, 31};
        int h = 0;
        for (char c : s)
            h = (h * primes[row] + c) % CMS_COLS;
        return (h + CMS_COLS) % CMS_COLS;
    }

public:
    CountMinSketch() {
        // Initialise all counts to 0
        for (int i = 0; i < CMS_ROWS; i++)
            for (int j = 0; j < CMS_COLS; j++)
                table[i][j] = 0;
    }

    // ── UPDATE: add count for integer x ──────
    void update(int x, int count = 1) {
        cout << "Updating \"" << x << "\" by " << count << ":\n";
        for (int i = 0; i < CMS_ROWS; i++) {
            int col = hashFn(i, x);
            table[i][col] += count;
            cout << "  Row " << i << " Col " << col
                 << " → " << table[i][col] << "\n";
        }
    }

    // ── QUERY: estimate frequency of integer x ─
    int query(int x) {
        int minVal = INT_MAX;
        for (int i = 0; i < CMS_ROWS; i++) {
            int col = hashFn(i, x);
            minVal = min(minVal, table[i][col]);
        }
        return minVal;  // minimum across all rows = best estimate
    }

    // ── UPDATE: add count for string s ────────
    void updateStr(string s, int count = 1) {
        cout << "Updating \"" << s << "\" by " << count << ":\n";
        for (int i = 0; i < CMS_ROWS; i++) {
            int col = hashStr(i, s);
            table[i][col] += count;
            cout << "  Row " << i << " Col " << col
                 << " → " << table[i][col] << "\n";
        }
    }

    // ── QUERY: estimate frequency of string s ─
    int queryStr(string s) {
        int minVal = INT_MAX;
        for (int i = 0; i < CMS_ROWS; i++) {
            int col = hashStr(i, s);
            minVal = min(minVal, table[i][col]);
        }
        return minVal;
    }

    // ── DISPLAY: print the 2D table ───────────
    void display() {
        cout << "Count-Min Sketch table:\n";
        cout << "     ";
        for (int j = 0; j < CMS_COLS; j++)
            cout << "C" << j << "  ";
        cout << "\n";
        for (int i = 0; i < CMS_ROWS; i++) {
            cout << "R" << i << " [ ";
            for (int j = 0; j < CMS_COLS; j++)
                cout << table[i][j] << "   ";
            cout << "]\n";
        }
    }
};

int main() {
    CountMinSketch cms;
    int choice, val, count;
    string s;

    cout << "===== COUNT-MIN SKETCH =====\n";
    do {
        cout << "\n1. Update integer\n";
        cout << "2. Query integer\n";
        cout << "3. Update string\n";
        cout << "4. Query string\n";
        cout << "5. Display table\n";
        cout << "0. Exit\n";
        cout << "Choice: ";
        cin >> choice;

        switch(choice) {
            case 1:
                cout << "Enter integer: "; cin >> val;
                cout << "Enter count: ";   cin >> count;
                cms.update(val, count);
                break;
            case 2:
                cout << "Enter integer: "; cin >> val;
                cout << "Estimated frequency: " << cms.query(val) << "\n";
                break;
            case 3:
                cout << "Enter string: "; cin >> s;
                cout << "Enter count: ";  cin >> count;
                cms.updateStr(s, count);
                break;
            case 4:
                cout << "Enter string: "; cin >> s;
                cout << "Estimated frequency: " << cms.queryStr(s) << "\n";
                break;
            case 5:
                cms.display();
                break;
            case 0:
                cout << "Bye!\n";
                break;
        }
    } while(choice != 0);

    return 0;
}