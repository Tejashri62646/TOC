#include<iostream>
using namespace std;

class Heap {
    int water[100];
    string name[100];
    int size;

public:
    Heap() {
        size = 0;
    }

    void insert(string n, int w) {
        int i = size;

        name[i] = n;
        water[i] = w;
        size++;

        // Max Heapify Up
        while(i != 0 && water[(i - 1) / 2] < water[i]) {

            swap(water[i], water[(i - 1) / 2]);
            swap(name[i], name[(i - 1) / 2]);

            i = (i - 1) / 2;
        }
    }

    void displayHighest() {
        if(size == 0) {
            cout << "Heap is Empty";
            return;
        }

        cout << "\nHighest Water Usage:\n";
        cout << "Owner Name : " << name[0] << endl;
        cout << "Water Usage: " << water[0] << " liters";
    }
};

int main() {

    Heap h;
    int n, w;
    string name;

    cout << "Enter number of houses: ";
    cin >> n;

    for(int i = 0; i < n; i++) {

        cout << "\nEnter Owner Name: ";
        cin >> name;

        cout << "Enter Water Usage: ";
        cin >> w;

        h.insert(name, w);
    }

    h.displayHighest();

    return 0;
}